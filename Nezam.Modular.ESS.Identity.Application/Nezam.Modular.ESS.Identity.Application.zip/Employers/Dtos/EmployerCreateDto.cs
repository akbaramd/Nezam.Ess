﻿namespace Nezam.Modular.ESS.Identity.Application.Employers.Dtos;

public class EmployerCreateDto
{
    
}

public class EmployerUpdateDto
{
    
}