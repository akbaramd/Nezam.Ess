using Bonyan.IdentityManagement.Domain.Roles.ValueObjects;
using Bonyan.UserManagement.Application.Users.Dto;
using FastEndpoints;
using Microsoft.AspNetCore.Mvc;
using Nezam.Modular.ESS.Identity.Application.Employers.Dtos;

namespace Nezam.Modular.ESS.Identity.Application.Users.Dto;

public class UserDto : BonUserDto
{

}

public class UserDtoWithDetail : UserDto
{

    public EmployerDto? Employer { get; set; }
    public Engineers.Dtos.EngineerDto? Engineer { get; set; }
}
public class UserFilterDto 
{

    [QueryParam]
    public int Take { get; set; }
    [QueryParam]
    public int Skip { get; set; }

    [QueryParam]
    public string? Search { get; set; }
    
    [QueryParam]
    public string SortBy { get; set; }
    
    [QueryParam]
    public string SortDirection { get; set; }
    
    
}

public class UserUpdateDto 
{
    [FromRoute]
    public Guid BonUserId { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }
    public BonRoleId[] RolesIds { get; set; }
}

