using Bonyan.IdentityManagement.Domain.Roles.DomainServices;
using Bonyan.IdentityManagement.Domain.Roles.Repostories;
using Bonyan.IdentityManagement.Domain.Users.DomainServices;
using Bonyan.Layer.Application.Services;
using Bonyan.Layer.Domain.Repository.Abstractions;
using Bonyan.UserManagement.Domain.Users.ValueObjects;
using Nezam.Modular.ESS.Identity.Application.Users.Dto;
using Nezam.Modular.ESS.Identity.Application.Users.Specs;
using Nezam.Modular.ESS.Identity.Domain.User;

namespace Nezam.Modular.ESS.Identity.Application.Users;

public class UserService : BonApplicationService, IUserService
{
    public IUserRepository UserRepository => LazyServiceProvider.LazyGetRequiredService<IUserRepository>();
    public IBonIdentityRoleRepository RoleRepository => LazyServiceProvider.LazyGetRequiredService<IBonIdentityRoleRepository>();
    public IBonIdentityUserManager<UserEntity> UserDomainService => LazyServiceProvider.LazyGetRequiredService<IBonIdentityUserManager<UserEntity>>();
    public IBonIdentityRoleManager RoleManager => LazyServiceProvider.LazyGetRequiredService<IBonIdentityRoleManager>();

    // Retrieves paginated user results based on the provided filter
    public async Task<BonPaginatedResult<UserDtoWithDetail>> GetBonPaginatedResult(UserFilterDto filterDto)
    {
        var result = await UserRepository.PaginatedAsync(new UsersFilterSpec(filterDto));
        return Mapper.Map<BonPaginatedResult<UserEntity>, BonPaginatedResult<UserDtoWithDetail>>(result);
    }

    // Gets a user by their ID
    public async Task<UserDtoWithDetail> GetUserByIdAsync(BonUserId BonUserId)
    {
        var user = await UserRepository.GetOneAsync(new UserByIdSpec(BonUserId));
        if (user == null) throw new Exception("User not found");

        return Mapper.Map<UserEntity, UserDtoWithDetail>(user);
    }

    // Updates a user's contact info and roles
    public async Task<UserDtoWithDetail> UpdateUserAsync(BonUserId BonUserId, UserUpdateDto updateUserDto)
    {
        var user = await UserRepository.GetOneAsync(new UserByIdSpec(BonUserId));
        if (user == null) throw new Exception("User not found");

        // Update contact info using encapsulated method
        user.UpdateContactInfo(updateUserDto.Email, updateUserDto.PhoneNumber);

        // Update roles via UserDomainService to handle encapsulation and business logic
        if (updateUserDto.RolesIds != null && updateUserDto.RolesIds.Length > 0)
        {
            await UserDomainService.AssignRolesAsync(user, updateUserDto.RolesIds.ToList());
        }

        await UserRepository.UpdateAsync(user);
        return Mapper.Map<UserEntity, UserDtoWithDetail>(user);
    }

    // Deletes a user by their ID
    public async Task<bool> DeleteUserAsync(BonUserId BonUserId)
    {
        var user = await UserRepository.GetByIdAsync(BonUserId);
        if (user == null) return false;

        await UserRepository.DeleteAsync(user);
        return true;
    }

   
    // Additional Methods Using UserDomainService and RoleManager


    // Resets a user's password
    public async Task<bool> ResetPasswordAsync(BonUserId BonUserId, string newPassword)
    {
        var user = await UserRepository.GetByIdAsync(BonUserId);
        if (user == null) throw new Exception("User not found");

        return (await UserDomainService.ResetPasswordAsync(user, newPassword)).IsSuccess;
    }
}
